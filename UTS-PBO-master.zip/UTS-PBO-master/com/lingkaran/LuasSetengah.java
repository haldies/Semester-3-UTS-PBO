/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lingkaran;

/**
 *
 * @author user
 */
public class LuasSetengah {
    private Lingkaran lingkaran;
    
    public LuasSetengah(Lingkaran lingkaran){
        lingkaran = this.lingkaran;
    }
    
    public void hitung(){
        this.lingkaran.hitungLuas();
                
    }
}
