/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.lingkaran;

/**
 *
 * @author user
 */
public interface Lingkaran {
    int panjang = 12;
    int lebar = 7;
    
    void hitungLuas();
}
